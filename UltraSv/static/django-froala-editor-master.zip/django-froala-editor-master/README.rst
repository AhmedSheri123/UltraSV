Django Froala WYSIWYG Editor
============================

    django-froala-editor package helps integrate `Froala WYSIWYG HTML
    editor <https://froala.com/wysiwyg-editor/>`__ with Django.

View the full documentation at `Github. <https://github.com/froala/django-froala-editor/>`__